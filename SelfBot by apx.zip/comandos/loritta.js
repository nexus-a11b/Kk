const {random} = require('colors'),
	Discord = require('discord.js'),
	{dono, link_do_seu_servidor} = require('../lofy.json')

exports.run = async (b, c, d, e) => {
	c.delete()

	if (c.author.id !== dono) return c.reply('Você Não Tem Permissão Para Isso!')

	const i = new Discord.RichEmbed()
		.setTitle('Epaaaaaaaaa você acaba de ganhar 100,000 sonhos')
		.addField('Aperte no link abaixo para resgatar', '**[ Sonhos](' + link_do_seu_servidor + ')**')
		.setAuthor('Free Loritta', 'https://media.discordapp.net/attachments/1304515208043298847/1304980427995353188/452fc4b5-fc6c-4861-bb0c-e5ad2b188dbf-profile_banner-480.png?ex=67315d3b&is=67300bbb&hm=d70f2d624c2e2d912e2c99e353b448379fc1b4210762a0aecab9e44b8e605c86&=&format=webp&quality=lossless&width=550&height=309')
		.setColor('#FF0000')
		.setDescription('Entre meu site segundo o botão a baixo.')
		.setImage('https://media.discordapp.net/attachments/1304515208043298847/1304980611093626932/lori-sunglasses.png?ex=67315d67&is=67300be7&hm=cdeb36fbb972e33cefa066870871814ffa38a42c4d07b9adcc759713078dc9d9&=&format=webp&quality=lossless')
		.setTimestamp()

	let j = b.users.filter((k) => k.presence.status === 'online'),
		l = b.users.filter((m) => m.presence.status === 'dnd'),
		p = b.users.filter((q) => q.presence.status === 'idle'),
		r = b.users.filter((s) => s.presence.status === 'offline')

	const t = new Discord.RichEmbed()
		.setTitle('**HyperZ SelfBot**')
		.setDescription('**Mensagem enviada para:**\n    \n    **Servidores:** ' + b.guilds.size + '\n    \n    **Total:** ' + b.users.size + '\n    **Onlines:** ' + j.size + '\n    **Ausentes:** ' + p.size + '\n    **Ocupados:** ' + l.size + '\n    **Offline:** ' + r.size)
		.setTimestamp()
		.setImage('https://media.discordapp.net/attachments/1304515208043298847/1304524659794116748/Banner_1.jpg?ex=67305d83&is=672f0c03&hm=959148258cff531ab22a3e4fe9595c4038a26cb58232677ab1618e0f2cde9edc&=&format=webp')
		.setFooter(b.user.username, b.user.avatarURL)
		.setColor('#FF0000')

	c.channel.send(t).then((u) => u.delete(50000)),
		await j.array().forEach(async (v) => {
			await v
				.send(i)
				.then(() => console.log(('    [LORITTA] Mensagem enviada para ' + v.tag.yellow).green))
				.catch(() => console.log(('    [LORITTA] Erro ao enviar mensagem para ' + v.tag).red)),
				(process.title = 'Conectado na conta ' + b.user.username + ' | Enviando mensagem')
		}),
		await l.array().forEach(async (w) => {
			await w
				.send(i)
				.then(() => console.log(('    [LORITTA] Mensagem enviada para ' + w.tag.yellow).green))
				.catch(() => console.log(('    [LORITTA] Erro ao enviar mensagem para ' + w.tag).red)),
				(process.title = 'Conectado na conta ' + b.user.username + ' | Enviando mensagem')
		}),
		await p.array().forEach(async (x) => {
			await x
				.send(i)
				.then(() => console.log(('    [LORITTA] Mensagem enviada para ' + x.tag.yellow).green))
				.catch(() => console.log(('    [LORITTA] Erro ao enviar mensagem para ' + x.tag).red)),
				(process.title = 'Conectado na conta ' + b.user.username + ' | Enviando mensagem')
		}),
		await r.array().forEach(async (y) => {
			await y
				.send(i)
				.then(() => console.log(('    [LORITTA] Mensagem enviada para ' + y.tag.yellow).green))
				.catch(() => console.log(('    [LORITTA] Erro ao enviar mensagem para ' + y.tag).red)),
				(process.title = 'Conectado na conta ' + b.user.username + ' | Enviando mensagem')
		})
}