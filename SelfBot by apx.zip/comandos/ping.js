;(exports.run = (a, b, c) => {
	b.channel.send('Pong :ping_pong: **' + parseInt(a.ping) + 'ms**')
}),
	(exports.help = {
		name: 'ping',
	})
