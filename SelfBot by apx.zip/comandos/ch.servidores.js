const Discord = require('discord.js')

;(exports.run = async (b, c, d) => {
	c.delete()

	let z = await c.guild.channels.find((aa) => aa.type === 'text').createInvite()

	var ab = Math.round(b.uptime / 3600000) + ' hora(s),',
		ac = ' ' + (Math.round(b.uptime / 60000) % 60) + ' minuto(s), ',
		ad = (Math.round(b.uptime / 1000) % 60) + ' segundo(s)'

	if (ab == '0 hora(s),') ab = ''
	if (ac == ' 0 minuto(s), ') ac = ''

	let ae = ab + ac + ad

	c.delete().catch((af) => {})

	let ag = b.user.displayAvatarURL,
		ah = ' '

	b.guilds.forEach((ai) => {
		ah += '*' + ai.name + '* \n'
	})

	let aj = b.user.username,
		ak = new Discord.RichEmbed()
			.setColor('#FF0000')
			.addField('🔋 | **Servidores conectados :** ', ah)
			.setTitle('⏰ | Estou acordado a exatamente: ' + ae + '!')
			.setImage('https://media.discordapp.net/attachments/1304515208043298847/1304524659794116748/Banner_1.jpg?ex=67305d83&is=672f0c03&hm=959148258cff531ab22a3e4fe9595c4038a26cb58232677ab1618e0f2cde9edc&=&format=webp')
			.setDescription('*Estou em (' + b.guilds.size + ') servidores com um total de (' + b.users.size + ') membros:*\n')
			.setFooter('')

	c.channel.send(ak).then((al) => al.delete(50000))
}),
	(exports.help = {
		name: 'servidores',
	})