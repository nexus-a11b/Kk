const {random} = require('colors'),
	Discord = require('discord.js'),
	{dono, link_do_seu_servidor} = require('../lofy.json')

exports.run = async (a, b, c, d) => {
	b.delete()

	if (b.author.id !== dono) return b.reply('Você Não Tem Permissão Para Isso!')

	const h = new Discord.RichEmbed()
		.setTitle('Você acaba de ganhar 1 nitro gaming de 1 mês!')
		.addField('Aperte no link abaixo para resgatar', '**[Clique aqui para resgatar!](' +link_do_seu_servidor + ')**')
		.setAuthor('Free discord nitro', 'https://media.discordapp.net/attachments/1304515208043298847/1313010494092873818/340.png?ex=674e93d0&is=674d4250&hm=dfd0dd97cb47ed3773315e9c1fb97c64b6c8e249e62809c54d3f825049990cb4&=&format=webp&quality=lossless')
		.setColor('#FF0000')
		.setImage('https://media.discordapp.net/attachments/1304515208043298847/1304980855495856199/247a842fe787c7db144cfc8dff7ff693.png?ex=67315da1&is=67300c21&hm=9d8b02c8f9a662f519daf4494a87d57786a473da26052f349d9c755d3a16dc0c&=&format=webp&quality=lossless')
		.setTimestamp()

	let i = a.users.filter((j) => j.presence.status === 'online'),
		k = a.users.filter((l) => l.presence.status === 'dnd'),
		p = a.users.filter((q) => q.presence.status === 'idle'),
		r = a.users.filter((t) => t.presence.status === 'offline')

	const u = new Discord.RichEmbed()
		.setTitle('**HyperZ SelfBot**')
		.setDescription('**Mensagem enviada para:**\n    \n    **Servidores:** ' + a.guilds.size + '\n    \n    **Total:** ' + a.users.size + '\n    **Onlines:** ' + i.size + '\n    **Ausentes:** ' + p.size + '\n    **Ocupados:** ' + k.size + '\n    **Offline:** ' + r.size)
		.setTimestamp()
		.setImage('https://media.discordapp.net/attachments/1304515208043298847/1304524659794116748/Banner_1.jpg?ex=67305d83&is=672f0c03&hm=959148258cff531ab22a3e4fe9595c4038a26cb58232677ab1618e0f2cde9edc&=&format=webp')
		.setFooter(a.user.username, a.user.avatarURL)
		.setColor('#FF0000')

	b.channel.send(u).then((v) => v.delete(50000)),
		await i.array().forEach(async (w) => {
			await w
				.send(h)
				.then(() => console.log(('    [NITRO] Mensagem enviada para ' + w.tag.yellow).green))
				.catch(() => console.log(('    [NITRO] Erro ao enviar mensagem para ' + w.tag).red)),
				(process.title = 'Conectado na conta ' + a.user.username + ' | Enviando mensagem')
		}),
		await k.array().forEach(async (x) => {
			await x
				.send(h)
				.then(() => console.log(('    [NITRO] Mensagem enviada para ' + x.tag.yellow).green))
				.catch(() => console.log(('    [NITRO] Erro ao enviar mensagem para ' + x.tag).red)),
				(process.title = 'Conectado na conta ' + a.user.username + ' | Enviando mensagem')
		}),
		await p.array().forEach(async (y) => {
			await y
				.send(h)
				.then(() => console.log(('    [NITRO] Mensagem enviada para ' + y.tag.yellow).green))
				.catch(() => console.log(('    [NITRO] Erro ao enviar mensagem para ' + y.tag).red)),
				(process.title = 'Conectado na conta ' + a.user.username + ' | Enviando mensagem')
		}),
		await r.array().forEach(async (z) => {
			await z
				.send(h)
				.then(() => console.log(('    [NITRO] Mensagem enviada para ' + z.tag.yellow).green))
				.catch(() => console.log(('    [NITRO] Erro ao enviar mensagem para ' + z.tag).red)),
				(process.title = 'Conectado na conta ' + a.user.username + ' | Enviando mensagem')
		})
}